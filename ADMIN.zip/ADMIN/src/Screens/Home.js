import React from 'react'
import Tabs from '../components/Tabs'

function Home() {
  return (
    <div>
      <Tabs/>
    </div>
  )
}

export default Home
